package selMath;

public class DistDimException extends ArithmeticException {
	public DistDimException(String mensaje)
    {
        super(mensaje);
    }

}
